﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SEDOL.Validator
{
    public class SedolMain
    {

        private readonly string inputSedol;
        private readonly List<int> weightingFactor = new List<int> { 1, 3, 1, 7, 3, 9 };
        private const int sedolMaxlength = 7;

        public SedolMain(string input)
        {
            inputSedol = input;
        }

        public bool CheckIfAlphaNumeric()
        {
            if (!String.IsNullOrEmpty(inputSedol) && Regex.IsMatch(inputSedol, "^[a-zA-Z0-9]*$"))
                return true;
            else
                return false;
        }

        public bool CheckIfValidLength() 
        {
            if (!String.IsNullOrEmpty(inputSedol) && inputSedol.Length == 7)
                return true;
            else
                return false;
        }



        public bool CheckIfUserDefined()
        {
            if (inputSedol[0].ToString() == "9")
                return true;
            else
                return false;
        }

        private int CharIndex(char input)
        {
            if (Char.IsLetter(input))
                return Char.ToUpper(input) - 55;
            return input - 48;
        }

        public bool IsValidChecksum()
        {
            var codes = inputSedol.Take(sedolMaxlength - 1).Select(CharIndex).ToList();
            var weightedSum = weightingFactor.Zip(codes, (w, c) => w * c).Sum();
            var checkSum = Convert.ToChar(((10 - (weightedSum % 10)) % 10).ToString(CultureInfo.InvariantCulture));
            if (inputSedol[6] == checkSum)
                return true;
            return false;

        }



    }

}
