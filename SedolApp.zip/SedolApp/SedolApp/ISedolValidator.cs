﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDOL.INTERFACES
{
    public interface ISedolValidator
    {
        ISedolValidationResult ValidateSedol(string input);
    }
}
