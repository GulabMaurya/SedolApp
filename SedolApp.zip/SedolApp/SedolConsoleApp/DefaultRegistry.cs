﻿using System;
using System.Collections.Generic;
using System.Text;
using StructureMap;
using StructureMap.Graph;
using SEDOL.INTERFACES;
using SEDOL.Validator;
namespace SEDOL.RunnerApp
{
        public class DefaultRegistry : Registry
        {
            public DefaultRegistry()
            {
                Scan(scan =>
                {
                    scan.TheCallingAssembly();
                    scan.WithDefaultConventions();
                });
               
               For<ISedolValidationResult>().Use<SedolValidationResult>();
               For<ISedolValidator>().Use<SedolValidator>();

        }
        }    
}
