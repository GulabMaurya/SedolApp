﻿using StructureMap;
using StructureMap.Graph;
using SEDOL.INTERFACES;
using SEDOL.Validator;
using System;

namespace SEDOL.RunnerApp
{
    public class SedolRunner
    {
        static void Main(string[] args)
        {

            var container = Container.For<DefaultRegistry>();

            var app = container.GetInstance<SedolCaller>();
            Console.WriteLine("Please enter the SEDOL:");
            string input = Console.ReadLine();
            var result = app.CallValidator(input);
            Console.WriteLine("Entered String: " + result.InputString.ToString());
            Console.WriteLine("IsValidSedol: " + result.IsValidSedol.ToString());
            Console.WriteLine("IsUserDefined: " + result.IsUserDefined.ToString());
            if (!string.IsNullOrEmpty(result.ValidationDetails))
                Console.WriteLine("Validation Details: " + result.ValidationDetails.ToString());
            else
                Console.WriteLine("Validation Details: " + null);
            Console.ReadLine();
        }
    }
}
